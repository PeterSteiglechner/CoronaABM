
from ABM_corona import *
import config

config.std_inc = 4.39  # 2.41 # Lauer 2020
config.T_inc_avg = 7.44  #5.52 #Lauer 2020
config.phi = np.sqrt(config.std_inc**2+config.T_inc_avg**2)
config.mu_Inc = np.log(config.T_inc_avg**2/config.phi)
config.sigma_Inc = np.sqrt(np.log(config.phi**2/config.T_inc_avg**2))

N = 5000
Nc = 4
T = 200

seeds_noPol = np.arange(70,80, step=1)
config.folder="Runs23Apr/NoPol_Ma_5000/"
folder_NoPol= config.folder #"/home/peter/Corona/RunsFrom12April/NoPolEnsemble2/"

filename_noPol = lambda folder, seed: folder + "Run_N"+str(N)+"_Nc"+str(Nc)+"_T"+str(T)+"_policies__seed"+str(seed)+".ncdf"


for seed in seeds_noPol:
    #for trackDay in [5,10,15,20,25,30,35,40,45,50]:
    print(config.folder)
    print(seed)
    policies={
                'quarantine':[],  # Note: Now 0.8 fraction means: 0.8 of the total Pop! (perhaps more if of the 20% some are sick and in quarantine)
                'closeSchools':None, 
                'openSchools':None,#13+14,
                'closeLeisure':None, #13+7,
                'openLeisure':None,#,13+31+15,
                'closeWork':[],#[[13+22, fraction]],
                'openWork':[],#,[[13+31+15, fraction]],
                'trackPath':None,#12,
                'sloppytrackPath':None,
                'carefulCitizens':[],#[[12, 0.7], [13+15,0.9]],
                }
    #name = run(N,Nc,T, policies, seed)
    #print(name)
    

seeds_Pol=seeds_noPol #np.arange(30,35)
Policy="NoPol (Ma T_inc)"
filename_Pol = None#lambda folder, seed: filename_noPol(folder, seed)
folder_Pol=None
#folder+"Run_N2500_Nc2_T150_policies_trackPath-12,carefulCitizens0.7-12,closeSchools-13,closeLeisure-20,openSchools-27,carefulCitizens0.9-28,closeWork0.7-35,openLeisure-59,openWork0.7-59_seed"+str(seed)+".ncdf"

plot(folder_NoPol, seeds_noPol, filename_noPol, folder_Pol, seeds_Pol, filename_Pol, Policy, contact_hist_gif=False, school_develop_gif=False)


#####################################
#####    POLICY RUN      ############
#####################################
seeds_Pol=np.arange(70,80, step=1)#np.random.randint(1,100,size=10)#arange(80,90, step=1)



config.std_inc = 4.39  # 2.41 # Lauer 2020
config.T_inc_avg = 7.44  #5.52 #Lauer 2020
config.phi = np.sqrt(config.std_inc**2+config.T_inc_avg**2)
config.mu_Inc = np.log(config.T_inc_avg**2/config.phi)
config.sigma_Inc = np.sqrt(np.log(config.phi**2/config.T_inc_avg**2))


#for t_s in np.arange(20,51,step=10):
config.folder="Runs23Apr/HeinsbergPol_Ma/"
folder_Pol = config.folder
Policy="Heinsberg (Ma T_inc)"
startday=16 # Febr
ncdf_name="Heinsberg_Ma"

for seed in seeds_Pol:
    #for trackDay in [5,10,15,20,25,30,35,40,45,50]:
    
    print(config.folder)
    print(seed)
    policies={
            'quarantine':[],  # Note: Now 0.8 fraction means: 0.8 of the total Pop! (perhaps more if of the 20% some are sick and in quarantine)
            'closeSchools':28-startday, 
            'openSchools':28-startday+31+15,
            'closeLeisure': 28-startday+8,
            'openLeisure':28-startday+31+31,
            'closeWork':[[28-startday+3, 0.3],[28-startday+22, 0.8]],
            'openWork':[[28-startday+31+13, 0.5],[28+31+31,1.0]],
            'sloppytrackPath':None,#27-startday,
            'trackPath':27-startday,
            'carefulCitizens':[[28-startday, 0.3], [28-startday+11,0.7], [28-startday+22,0.9]],
            }

    name = run(N,Nc,T, policies, seed, ncdf_name = ncdf_name)
    #print(name)

name= "Run_N"+str(N)+"_Nc"+str(Nc)+"_T"+str(T)+"_policies_"+ncdf_name+"_seedXX"

filename_Pol = lambda folder, seed: folder+name[:-2]+str(seed)+".ncdf"
plot(folder_NoPol, seeds_noPol, filename_noPol, folder_Pol, seeds_Pol, filename_Pol, Policy, contact_hist_gif=False, school_develop_gif=False)





    # HEINSBERG POLICY



#Heinsberg:
# 1.2. Start
# 27.2. Track Path
# 28.2. Close SChools for 14 days (until 13.03.)
# 07.03 Close Leisure (???)
# Until ttoday 15.4.
# 22.03. Close Work  70%
# Until today 15.04.


#config.folder="/home/peter/Corona/RunsFrom12April/TrackPathOnly/"
#"Run_N2500_Nc2_T150_policies_trackPath-12,carefulCitizens0.7-12,closeSchools-13,closeLeisure-20,openSchools-27,carefulCitizens0.9-28,closeWork0.7-35,openLeisure-59,openWork0.7-59_seed"+str(seed)+".ncdf"
