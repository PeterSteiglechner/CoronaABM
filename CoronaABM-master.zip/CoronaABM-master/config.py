import numpy as np
    

#######
## For Storing Results
#######
folder=""
store_all_agents= {'state':0, 'age_group_ind':0}
all_agents = []
policies = []
r0=[]

##### 
age_groups = ["child", "adult", "risk"]
# <30 years, 30-60 years, >60 years
probs_age_group = [0.30, 0.41, 0.29] # https://service.destatis.de/bevoelkerungspyramide/index.html#!a=30,60&g



states = {'Healthy':0,'Latent':1,'Active':2,'MildSymptomatic':3,'SevereSymptomatic':4,'Dead':5, 'Immune':6}

# AGENT PROPERTIES 
N_contacts_family = 4 
N_contacts_at_work = 5
N_contacts_at_school = 10
Dist = np.array([[1,0,0],
        [0.1, 0.6, 0.3], 
        [0,0.3, 0.7]
        ])
# LINKS
#  https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Soziales/Kinderhilfe-Jugendhilfe/Tabellen/einrichtung-taetige-personen.html
#  https://www.google.com/search?client=ubuntu&channel=fs&q=wie+viele+Lehrer+gibt+es+in+Deutschland&ie=utf-8&oe=utf-8
#  https://www.destatis.de/DE/Themen/Gesellschaft-Umwelt/Soziales/Kindertagesbetreuung/_inhalt.html
#  roughly 750k teachers, 250k kinderundjugendhilfe, 600k child care
#  --> roughly 2mio of 34mio --> roughly 5%
#  of >60years: 10mio of 23mio between 60 and 70 AND 1/3 is 60-67,
N_contacts_in_leisuregroup = 3
Nr_leisuregroups_per_person = 3

avg_Nr_randomContacts = 3
sig_Nr_randomContacts = 1
movingRadius = 0.02
randomRadius = 0.2
distMatrix = np.zeros([1,1])

quarantine_delay = 1 # 1 day after getting sick the agent goes to quarantene
quarantine_Nr_random_contacts = 1.5
quarantine_Nr_random_contacts_std = 0.33

N_workplaces = 0 # will be filled
N_schools = 0 # will be filled
N_Leisuregroups_per_age = 0 # will be filled
group_arr_sorted=[] # will be filled
ClosedWorks=[]



######## CORONA  ################
std_inc = 2.41 # Lauer 2020
T_inc_avg = 5.52 #Lauer 2020
phi = np.sqrt(std_inc**2+T_inc_avg**2)
mu_Inc = np.log(T_inc_avg**2/phi)
sigma_Inc = np.sqrt(np.log(phi**2/T_inc_avg**2))

#PrePeakInfectiousnessPeriod = 1.5 # He 2020 (roughly)
#Time_PeakBeforeTs = 0.5 # IC say it starts there, He say peak 0 to 2 days before. Didn't someonw else say 0.5 days before symtom onset?!?

#Infectivity = 0.04
#p_i_alpha=2
#config.PostPeakInfectiousnessPeriod=--> Recovery gaussian

# --> T_truncate infectiousness
#T_avg_recovery_asymptomatic = 9 # Woelfel
#T_sigma_recovery_asymptomatic = 3  # Woelfel 6 to 12 days


T_avg_recovery_symptomatic = 24.7  # Verity2020
CoefficientOfVariation_recovery_symptomatic=0.35
k_recov_sympt =  (1/CoefficientOfVariation_recovery_symptomatic)**2 #shape
theta_recov_sympt =(CoefficientOfVariation_recovery_symptomatic**2)*T_avg_recovery_symptomatic


########################
####  SYMPTOMS ETC   ###
########################
# Manifestation Index = #symptomatic / #infected. 
# 
# Mizumoto2020 says 82 Percent for all people on Diamond but mostly >60yrs developed symptoms
# Nishiura2020 says 69 Percent for Japanese Evacuation (I assume this is mostly work related )
# for children, no number available: 0.2 is random.
ManifestationIndex = [0.5,0.7, 0.8]  

# Roughly from Ferguson2020 # adjusted since european society is much older... (I should probably adjust the CFR as well)
SevereFraction = [0.01, 0.05, 0.2] 
# Verity 2020
#       <= 60 years: 0.318% --> = 0% *0.31 (children) + CFR_adults * 0.41
#       --> CFR_children = 0, CFR_adults = 0.55%
#       > 60 years: 6.38% 
#CaseFatalityRate = [0.0, 0.0055,0.0638]
CaseFatalityRate = [0.0, 0.005,0.06]# TODO IS THIS REALlY PER INFECTED? OR PER HOSPITLAISED

T_avg_death = 18.8  # Verity2020
#sigma_death = 5
CoefficientOfVariation_death = 0.45 # Verity2020
k_death =  (1/CoefficientOfVariation_death)**2 #shape
theta_death =(CoefficientOfVariation_death**2)*T_avg_death


#symptom_amplification_factor = 1.5 # Imperial College  # when sick/showing symptoms, then agent is 2x as infectious.
MaxQuarantineDays = 14 # 2* T_inc_avg

# Woelfel 
T_truncate_infectiousness = 8 # He2020 (significant decline 8 d after symptom onset)
# Taken from https://github.com/ehylau/COVID-19 the code of He2020
par1 = 2.115779 # shape
par2 = 0.6898583 # rate
par3 = 2.306691 # shift
He2020_params={'shift':par3,'k_i':par1, 'rate_i': par2}
R0_noIsolationWithSymptoms= 9# NEED TO TUNE!
avg_Nr_Contacts = avg_Nr_randomContacts + N_contacts_family + N_contacts_in_leisuregroup + np.sum([probs_age_group[k]*Dist[k]*np.array([N_contacts_at_school, N_contacts_at_work, 0]) for k in range(3)]) 
p_i_factor =  R0_noIsolationWithSymptoms /avg_Nr_Contacts  # 

Prefactor_P_i_asymptoticTransmission = 0.2 # Ferretti2020: says 0.1, but they didn't have children
Prefactor_P_i_mildsymptoticTransmission = 0.55 # Ruiyun Li 2020: Model says undocumented (light symptoms, asymptomatic) are 55% as infectious as documented cases