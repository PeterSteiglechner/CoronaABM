import xarray as xr
import matplotlib.pyplot as plt
import numpy as np 
# from ncdf_plot_functions import dataset_get_state_hist
# import pandas as pd
import matplotlib.animation as animation

import matplotlib as mpl
from pathlib import Path


import sys




RCPARAMS = {'font.size':20}
plt.rcParams.update(RCPARAMS)

# runs=[]
# for seed in np.arange(100,110):
# runs.append(xr.open_dataset("/home/peter/Persönliches_Bremen/Corona/RunsFrom12April/NoPolEnsemble/Run_N5000_Nc3_T150_policies__seed"+str(seed)+".ncdf"))

colors = np.array(["lightgreen", "yellow", "orange", "pink", "r", "k", "darkgreen"])
states =np.array(["Healthy", "Latent", "Active", "Mild Symptoms", "Severe Symptoms", "Dead", "Immune"])

#ds = runs[0]
def plot_single(ds):
    fig=plt.figure(figsize=(16,9))
    ax = fig.add_subplot(111)
    for k in ds.state_coord:
        ds.states_detail.sum(dim="age_group_ind_coord").sel(state_coord=k).plot(label=states[k.values], color=colors[k.values], lw=3)
    ax.legend()
    ax.grid()
    ax.set_ylim(0,len(ds.id))


def plot_meanRun(mean_data, std_data, ax=None, time=None, style="-", title_add=""):
    if time is None: 
        time = mean_data.shape[1]
    if ax is None:
        fig=plt.figure(figsize=(16,9))
        ax=fig.add_subplot(111)
    for k in range(5):
        ax.plot(time, mean_data[k,:], style, lw=3, alpha=1, color=colors[[1,2,3,4,5]][k], label=states[[1,2,3,4,5]][k])
        ax.fill_between(time, mean_data[k,:]-std_data[k,:], mean_data[k,:]+std_data[k,:], color=colors[[1,2,3,4,5]][k], alpha=0.4)
    ax.legend()

    ax.set_ylabel("Nr of People at specific day")
    ax.set_title("Ensemble Run, "+title_add)
    ax.set_xlabel("Time in days")
    ax.set_xlim(time[0], time[-1])
    ax.set_ylim(0,)
    ax.grid()
    return 

def plot_many(runs, ax=None, plotting=True, style="-", Policy=""):
    if ax==None and plotting:
        fig=plt.figure(figsize=(16,9))
        ax=fig.add_subplot(111)
    for _, ds in enumerate(runs):
        for k in ds.state_coord[1:6]:
            ds.states_detail.sum(dim = "age_group_ind_coord").sel(state_coord=k).plot(color=colors[k.values], lw=3, alpha = 0.1)
            #label=states[k.values]
        #if n==0:
        #    plt.legend()

    mean_data = np.array([np.mean([runs[n].states_detail.sum(dim = "age_group_ind_coord").sel(state_coord=k)  for n in range(len(runs))], axis=0) for k in [1,2,3,4,5]])

    std_data = np.array([np.std([runs[n].states_detail.sum(dim = "age_group_ind_coord").sel(state_coord=k)  for n in range(len(runs))], axis=0) for k in [1,2,3,4,5]])
    plot_meanRun(mean_data, std_data, ax=ax, time=ds.time, style=style, title_add=Policy+"(Total "+str(runs[0].N))
    return mean_data, std_data



#doubling_time_first60days
def get_doubling_time(run):
    starttime=5
    endtime=np.argmax(run).astype(int)
    def exp(t, doublingtime):
        return 2**(t/doublingtime)*run[starttime]
    import scipy.optimize as opt 
    res = opt.curve_fit(exp, np.arange(starttime,endtime), run[starttime:endtime])
    doubling_time_daystarttoend = res[0]
    print("Doubling Times in day "+str(starttime)+" to "+str(endtime)+" is: ", '%.2f' % doubling_time_daystarttoend, " days")
    return doubling_time_daystarttoend




#ds = runs[0]
def plot_and_get_r0(runs, Policy):
    plt.figure(figsize=(16,9))
    first10_mean=[]
    for ds in runs:
        start = ds.t_a.to_series().dropna()
        s = start.sort_values()
        #s.hist()
        #s.index

        r0 = ds.r0.to_series().dropna()
        r0_sorted = r0[s.index]
        #print(ds)
        N=20
        r0mean = np.convolve(r0_sorted, np.ones((N,))/N, mode='valid')
        s_conv = np.convolve(s.values, np.ones((N,))/N, mode='valid')

        first10_mean.append(np.mean(r0_sorted[:10]))
        plt.plot(s_conv, r0mean, '.-', lw=2)
    print("Averages of the First 10 R0 Values for each run:", first10_mean, " and the Avergae of that: ", np.mean(first10_mean))
    plt.ylabel("R0 (running mean, concolution with N ="+str(N)+")")
    plt.xlabel("Time")
    plt.title(Policy)
    plt.grid()
    return 



################ SERIAL INTERVAL

#run=runs[6]
def get_serial_intervals(runs, WithWithoutPol="None",plotting=False, folder=""):
    serial_Interval_mean_allRuns=[]
    Eligible_allRuns=[]
    #serial_Intervals_allRuns=[]

    for run in runs:
        serial_Interval = []
        for id in run.id:
            if not np.isnan(run.t_s.sel(id=id)):
                infector = run.infector.sel(id=id)
                if not np.isnan(infector):
                    if not np.isnan(run.t_s.sel(id=infector)):
                        serial_Interval.append(run.t_s.sel(id=id) - run.t_s.sel(id=infector))
        
        Eligible_allRuns.append(len(serial_Interval))

        if serial_Interval==[]:
            break

        serial_Interval_mean = np.mean(serial_Interval)
        serial_Interval_std= np.std(serial_Interval)
        
        if plotting:
            fig = plt.figure(figsize=(12,5))
            ax = fig.add_subplot(111)
            ax.hist(serial_Interval, bins=np.arange(max(serial_Interval)))
            ax.axvline(serial_Interval_mean,0, ax.get_ylim()[1], color='black')
            ax.fill_between([serial_Interval_mean-serial_Interval_std, serial_Interval_mean+serial_Interval_std], [0,0], [ax.get_ylim()[1], ax.get_ylim()[1]], color='gray', alpha=0.4)
            ax.set_ylabel("Count")
            ax.set_xlabel("Serial Intervals")
            ax.text(0.6, 0.8,"Eligible Infector-Infectee \n Pairs: "+str(len(serial_Interval)), transform=ax.transAxes)
            plt.savefig(folder+"SerialInterval_seed"+str(run.seed)+"_Pol_"+WithWithoutPol+".png")
            plt.close()
        print("Serial Interval is ", "%.2f" % serial_Interval_mean, " +- ", "%.2f" % serial_Interval_std, " (Nr of valid: ", Eligible_allRuns[-1], ")")

        serial_Interval_mean_allRuns.append(serial_Interval_mean)
    
    print("Over all runs Mean: ",np.mean(serial_Interval_mean_allRuns), " +- ",np.std(serial_Interval_mean_allRuns) )
    return np.mean(serial_Interval_mean_allRuns), np.std(serial_Interval_mean_allRuns), Eligible_allRuns




### ANALYSE CONTACTS 

def contacthistgif(runs_NoPol, runs_WithPol, Policy, interval=100 ):
    mean_contacthist_NoPol = np.mean([ds.Nr_contacts for ds in runs_NoPol], axis=0)
    mean_contacthist_Policy= np.mean([ds.Nr_contacts for ds in runs_WithPol], axis=0)

    fig, ax = plt.subplots()
    BarsNo = ax.bar(runs_NoPol[0].dim_hist_contacts.values, mean_contacthist_NoPol[:,0], label="No Policy")
    BarsWith = ax.bar(runs_WithPol[0].dim_hist_contacts.values, mean_contacthist_Policy[:,0], alpha=0.7, label="With Policy: "+str(Policy))
    ax.set_ylim(0,100)
    ax.set_title("Time "+str(0)+": "+Policy)

    def animate_compare(t):
        #line.set_ydata()  # update the data
        for i, b in enumerate(BarsNo):
            b.set_height(mean_contacthist_NoPol[i,t])
        for i, b in enumerate(BarsWith):
            b.set_height(mean_contacthist_Policy[i,t])
        ax.set_title("Time "+str(t)+": "+Policy)
        return BarsNo

    #def animate_single(t):
    #    #line.set_ydata()  # update the data
    #    for i, b in enumerate(BarsNo):
    #        b.set_height(mean_contacthist_NoPol[i,t])
    #    #for i, b in enumerate(BarsWith):
    #    #    b.set_height(ds.Nr_contacts.sel(time=t, dim_hist_contacts=i).values)
    #    ax.set_title("Time "+str(t))
    #    #if t>=int(ds.policies_[10:]):
    #    #    ax.set_title("Time "+str(t)+": School Closed since day "+ds.policies_[10:])
    #    return BarsNo


    ani = animation.FuncAnimation(fig, animate_compare, runs_WithPol[0].time.values, interval=interval)
    return ani



# A FEW COURSES OF INFECTION

def plot_courses_of_infection(run, AgentID):
    def verlauf(a):
        verlauf=[0,a.t_e.values, a.t_a.values, a.t_s.values if a.severe==False else np.nan, a.t_s.values if a.severe else np.nan, a.t_r.values, a.t_d.values, a.time.isel(time=-1).values]
        for t in range(1,7)[::-1]:
            if np.isnan(verlauf[t]):

                verlauf[t]=verlauf[t+1]
        return verlauf
    #colors=["lightgreen","yellow", "orange", "pink", "red", "darkgreen", "k"]
    alphas = [0,1,1,1,1,0,1]
    def plot_verlauf(a, y, ax):
        v = verlauf(a)
        for k in range(6):
            b = ax.barh(y,v[k+1]-v[k], height=0.8, left=v[k], color=colors[k], alpha=alphas[k])
        return b

    good_index = np.argpartition(run.t_e.values, 10)
    print(good_index[:10])
    # a
    ax=plt.figure(figsize=(16,5)).add_subplot(111)
    age=[]
    a = run.sel(id =AgentID)
    count=0
    #for level in range(Level_N):
    count+=1
    age.append(a.age_group_ind)
    start_arrow= np.array([a.t_a, -count])
    plot_verlauf(a, -count, ax)

    infectees = run.id.where(run.infector==a.id).to_series().dropna().values
    # plot arrows to these infectees
    for _, i in enumerate(infectees):
        count+=1
        a=run.sel(id=i)
        plot_verlauf(a, -count, ax)
        age.append(a.age_group_ind)

        end_arrow = np.array([a.t_e, -count])
        start_arrow[0]=end_arrow[0]
        plt.annotate("", end_arrow,start_arrow,  arrowprops=dict(arrowstyle="->"))
        #print(start_arrow, d_arrow)
        sub_infectees = run.id.where(run.infector==a.id).to_series().dropna().values
        start_subarrow= np.array([a.t_a, -count])
        for _, sub_i in enumerate(sub_infectees):
            count+=1
            a=run.sel(id=sub_i)
            plot_verlauf(a, -count, ax)
            age.append(a.age_group_ind)

            end_subarrow = np.array([a.t_e, -count]) 
            start_subarrow[0]=end_subarrow[0]
            plt.annotate("",  end_subarrow, start_subarrow,arrowprops=dict(arrowstyle="->"))
            
            #print(smallRun.infector.sel(id=a.id).values)
            #if np.isnan(smallRun.infector.sel(id=a.id)):
            #    break
            #a = smallRun.sel(id=smallRun.infector.sel(id=a.id))
    ax.set_yticks(np.arange(-1,-len(age)-1, step=-1))
    ax.set_yticklabels([['child', 'adult', 'elderly'][ag.values] for ag in age])
    return   good_index[:10]







##### PLOT SCHOOLS 
def plot_schools(run, Policy):
    styles=["d", "o", "s"]
    def get_state(run, ag_id, ag_severe, t):
        #states={'Healthy':0, "Latent":1, "Active":2, "Mild Symptoms":3, "Severe Symptoms":5,  "Immune":5,"Dead":6}

        if np.isnan(run.t_e.sel(id=ag_id)) or run.t_e.sel(id=ag_id) >t:
            return states['Healthy']
        if run.t_e.sel(id=ag_id)<=t and (np.isnan(run.t_a.sel(id=ag_id)) or run.t_a.sel(id=ag_id)>t):
            return states['Latent']
        if run.t_a.sel(id=ag_id)<=t and (np.isnan(run.t_s.sel(id=ag_id)) or run.t_s.sel(id=ag_id)>t) and (np.isnan(run.t_r.sel(id=ag_id)) or run.t_r.sel(id=ag_id)>t):
            return states['Active']
        if run.t_s.sel(id=ag_id)<=t and (np.isnan(run.t_d.sel(id=ag_id)) or run.t_d.sel(id=ag_id)>t) and (np.isnan(run.t_r.sel(id=ag_id)) or run.t_r.sel(id=ag_id)>t):
            if ag_severe==False:
                return states["Mild Symptoms"]
            else:
                return states["Severe Symptoms"]
        if run.t_d.sel(id=ag_id)<=t:
            return states["Dead"]
        if run.t_r.sel(id=ag_id)<=t:
            return states['Immune']
        print("Error")

        
    def get_rectangles_ncdf(ax, run, t):
        AllSchools = [g for g in run.group_hist_index if "School"in g]
        agents_in_school = run.agentgroups[:,0][run.agentgroups[:,0]<len(AllSchools)].id
        agents_schools = run.agentgroups.sel(groups="Work",  id=agents_in_school).values

        GroupNames, GroupSizes=  np.unique(agents_schools, return_counts=True)

        rectangles = []
        ExtraCols=0
        for i in range(len(GroupNames)):
            rec = mpl.patches.Rectangle((i,0), 1, GroupSizes[i], fc='white', edgecolor="k", alpha=1, zorder=0)
            rectangles.append(rec)

        points=[]
        #single_count=0
        group_counts = np.zeros([len(GroupNames)+ExtraCols], dtype=np.uint8)
        for group, ag_id, ag_severe in zip(agents_schools, agents_in_school.id,agents_in_school.severe):
            state = get_state(run, ag_id,ag_severe , t)
            age = run.age_group_ind.sel(id=ag_id)
            color=colors[state]
            style=styles[age.values]
            x = int(group) # np.where(GroupNames==group)[0][0]
            y = group_counts[x]
            #if "Single" in group:
            #    x,y = single_cells[single_count]
            #    single_count +=1
            points.append([x,y ,color, style])
            group_counts[x]+=1
        points = np.array(points)

        for rec in rectangles:
            ax.add_artist(rec)
        for s in styles:
            ax.scatter(points[points[:,3]==s,0].astype(int)+0.5, points[points[:,3]==s,1].astype(int)+0.5, s=100, marker = s,c=points[points[:,3]==s,2])

        ax.set_ylim(0,max(points[:,1].astype(int))+2)
        ax.set_yticks(np.arange(ax.get_ylim()[0], ax.get_ylim()[1], step=5))

        ax.set_xticks(np.arange(len(GroupNames), step=5)+0.5)
        ax.set_xlim(0,len(GroupNames)+0.5)
        ax.set_xticklabels((ax.get_xticks()-0.5).astype(int), rotation =90)
        return points

    fig=plt.figure(figsize=(16,7))
    ax = fig.add_subplot(111)
    def update(t):
        points = get_rectangles_ncdf(ax, run, t)#.sel(id=np.arange(100)), 50)
        print(t, end=", ")
        ax.set_title("Time = "+str(t)+" "+Policy)
        return points
    update(0)

    ani = animation.FuncAnimation(fig, update, run.time.values, interval=750)
    #ani.save("RunsFrom12April/NoPolEnsemble2/SchoolDevelop_Run5.gif", writer='imagemagick')
    return ani



#######################################
#####   GET WHERE INFECTIONS OCCUR   ##
#######################################
def get_where_infections_occur(runs):
    place_counts_all = []
    type_counts_all=[]
    ageInfector_counts_all = []
    age_groups = ["child", "adult", "risk"]
    for run in runs:
        total = len(run.WhereInfection)

        place_counts = {'School':0, 'Work':0, "family":0, "Leisure":0, "random":0}
        place_keys = list(place_counts.keys())
        type_counts = {'Presympt':0, 'Asympt':0, 'MildSympt':0,'Sympt':0}
        type_keys = list(type_counts.keys())
        ageInfector_counts = {age_groups[0]:0,age_groups[1]:0, age_groups[2]:0}
        ageInfector_keys = age_groups
        
        for descr in run.WhereInfection:
            for k in place_keys:
                if k in descr:
                    place_counts[k] +=1/total
            for k in type_keys:
                if k in descr:
                    type_counts[k]+=1/total
            for k in ageInfector_keys:
                if ("Infector:"+k) in descr:
                    ageInfector_counts[k]+=1/total

        print([key+": "+'%.2f' % (place_counts[key]*100)+"%" for key in place_keys])
        print([key+": "+'%.2f' % (type_counts[key]*100)+"%" for key in type_keys])
        print([key+": "+'%.2f' % (ageInfector_counts[key]*100)+"%" for key in ageInfector_keys])

        place_counts_all.append(place_counts)
        type_counts_all.append(type_counts)
        ageInfector_counts_all.append(ageInfector_counts)


    return place_counts_all, type_counts_all, ageInfector_counts_all





#####################################
####  PLOT EVERYTHING #  ############
#####################################


def plot(folder_NoPol, seeds_noPol, filename_noPol, folder_Pol, seeds_Pol, filename_Pol, Policy, contact_hist_gif=False, school_develop_gif=False):
    
    
    # Create Analysis:
    if not folder_Pol==None:
        anafolder = folder_Pol+"Analysis/"
    else:
        anafolder=folder_NoPol+"Analysis/"
    Path(anafolder).mkdir(exist_ok=True, parents = True)

    orig_stdout = sys.stdout
    f = open(anafolder+'out.txt', 'w')
    sys.stdout = f


    # 0. Load Data

    runs_NoPol=[]
    for seed in seeds_noPol:
        runs_NoPol.append(xr.open_dataset(filename_noPol(folder_NoPol,seed)))

    if not folder_Pol==None:
        runs_WithPol=[]
        for seed in seeds_Pol:
            runs_WithPol.append(xr.open_dataset(filename_Pol(folder_Pol, seed)))


    # 1. Plot mean runs of no pol and compare and doubling Time
    print( "1. Plot mean runs of no pol and compare and doubling Time")
    plt.cla()
    meanRun_NoPol, std_NoPol= plot_many(runs_NoPol, Policy="No Policy")
    plt.savefig(anafolder+"Dynamics_MeanRun_NoPol.svg", bbox_inches='tight') 
    plt.close()
    if not folder_Pol==None:
        plt.cla()
        meanRun_WithPol, std_WithPol= plot_many(runs_WithPol, Policy=Policy)
        plt.savefig(anafolder+"Dynamics_MeanRun_Pol.svg", bbox_inches='tight') 
        plt.close()

    print(
        "No Pol: ", get_doubling_time(meanRun_NoPol[2,:]+meanRun_NoPol[3,:]),
    )
    if not folder_Pol==None:
        print(
            "With Policy ("+Policy+"): ", get_doubling_time(meanRun_WithPol[2,:]+meanRun_WithPol[3,:])
            )

    if not folder_Pol==None:
        plt.cla()
        fig=plt.figure(figsize=(16,9))
        ax=fig.add_subplot(111)
        plot_meanRun(meanRun_NoPol, std_NoPol, ax=ax, time=runs_NoPol[0].time.values, title_add=Policy+"(Total "+str(runs_NoPol[0].N)+")")
        plot_meanRun(meanRun_WithPol ,std_WithPol, ax=ax, style='--',time=runs_WithPol[0].time.values, title_add=Policy+"(Total "+str(runs_NoPol[0].N)+")")
        ax.set_title("No Policy vs. "+Policy+", Ensemble Runs"+" (Total "+str(runs_NoPol[0].N)+")")
        plt.savefig(anafolder+"Dynamics_CompareNoPolVsPol.svg", bbox_inches='tight')
        plt.close()

    # GET THE CUMMULATIVE SICK AND DEATH
    print("CUMMULATIVE SICK AGENTS")
    mean_cummSick_noPol = np.mean([runs_NoPol[k].t_s.dropna(dim="id").count() for k in range(len(runs_NoPol))])
    print("     NO POL: ", mean_cummSick_noPol)
    if not folder_Pol==None:
        mean_cummSick_withPol = np.mean([runs_WithPol[k].t_s.dropna(dim="id").count() for k in range(len(runs_WithPol))])
        print("     WITH POL: ", mean_cummSick_withPol)
    

    # 2. Get the R0 and Perhaps Contact Histogram GIF
    print("2. Get the R0 and Perhaps Contact Histogram GIF")
    print(" NO POL")
    plot_and_get_r0(runs_NoPol, "No Policy")
    plt.savefig(anafolder+"R0_NoPol.png", bbox_inches='tight')
    plt.close()
    if not folder_Pol==None:
        print(" WITH POL")
        plot_and_get_r0(runs_WithPol, Policy)
        plt.savefig(anafolder+"R0_WithPol.png", bbox_inches='tight')
        plt.close()

    if contact_hist_gif==True and not folder_Pol==None:
        ani = contacthistgif(runs_NoPol, runs_WithPol, Policy, interval=100 )
        ani.save(anafolder+"contact_hist.mp4", writer='imagemagick')

    # 3. GET SERIAL INTERVAL
    print("3. Serial Interval!")

    print("NoPol")
    #get_serial_intervals(runs_NoPol, WithWithoutPol="NoPolicy",plotting=True, folder=anafolder)

    if not folder_Pol==None:
        print("With Pol "+Policy)
        get_serial_intervals(runs_WithPol, WithWithoutPol="WithPolicy",plotting=True, folder=anafolder)
        

    # 4. COURSES
    print("4. The course of an infection of an individual and its infectees")
    id=0
    WithWithout ="No"
    runs = runs_NoPol
    if not folder_Pol==None:
        WithWithout="With"
        runs = runs_WithPol
    early_index = plot_courses_of_infection(runs[0], id)
    #plt.savefig(anafolder+"Course_"+WithWithout+"Pol_id"+str(id)+".png")
    #plt.close()
    for k in range(10):
        id = early_index[k]
        plot_courses_of_infection(runs[0], id)
        plt.savefig(anafolder+"Course_"+WithWithout+"Pol_id"+str(id)+".png")
        plt.close()
    #id = early_index[9]
    #plot_courses_of_infection(runs[0], id)
    #plt.savefig(anafolder+"Course_"+WithWithout+"Pol_id"+str(id)+".png")
    #plt.close()


    # 5. School:
    print("5. School MP4")
    if school_develop_gif==True:
        i=0
        ani = plot_schools(runs_WithPol[i], Policy)
        ani.save("SchoolDevelop_Run_"+str(i)+".mp4", writer='imagemagick')
   

    # 6. WHERE INFECTIONS OCCUR
    print("6. Where Infections occur")
    print("     No Pol: ")
    get_where_infections_occur(runs_NoPol)
    if not folder_Pol==None:
        print("     ")
        print("     With Pol: ", Policy)
        get_where_infections_occur(runs_WithPol)


    sys.stdout = orig_stdout
    f.close()
    return 



if __name__ == "__main__":
        

    
    # folder_NoPol = "/home/peter/Corona/RunsFrom12April/NoPol_RandomUpdate/"
    # seeds_noPol=np.arange(50,60)
    # filename_noPol = lambda folder, seed: folder + "Run_N2500_Nc2_T150_policies__seed"+str(seed)+".ncdf"
    # folder_Pol=None#"/home/peter/Corona/RunsFrom12April/Heinsberg_2/"
    # seeds_Pol=None#np.arange(30,35)
    # filename_Pol=None#"/home/peter/Corona/RunsFrom12April/Heinsberg_2/"
    # Policy=""
    # plot(folder_NoPol, seeds_noPol, filename_noPol, folder_Pol, seeds_Pol, filename_Pol, Policy, contact_hist_gif=False, school_develop_gif=False)

    # folder_NoPol= "/home/peter/Corona/RunsFrom12April/NoPolEnsemble2/"
    # seeds_noPol= np.arange(0,10)
    # folder_Pol=None#"/home/peter/Corona/RunsFrom12April/Heinsberg_2/"
    # seeds_Pol=None#np.arange(30,35)
    # Policy="HeinsbergRoughly"
    # filename_noPol = lambda folder, seed: folder + "Run_N2500_Nc2_T150_policies__seed"+str(seed)+".ncdf"
    # filename_Pol = lambda folder, seed: folder+"Run_N2500_Nc2_T150_policies_trackPath-12,carefulCitizens0.7-12,closeSchools-13,closeLeisure-20,openSchools-27,carefulCitizens0.9-28,closeWork0.7-35,openLeisure-59,openWork0.7-59_seed"+str(seed)+".ncdf"

    # plot(folder_NoPol, seeds_noPol, filename_noPol, folder_Pol, seeds_Pol, filename_Pol, Policy, contact_hist_gif=False, school_develop_gif=False)
        
    seeds_noPol = np.arange(60,70, step=1)
    folder="/home/peter/Corona/Runs22Apr/NoPol/"
    folder_NoPol= folder #"/home/peter/Corona/RunsFrom12April/NoPolEnsemble2/"
    filename_noPol = lambda folder, seed: folder + "Run_N2500_Nc3_T150_policies__seed"+str(seed)+".ncdf"
       
    seeds_Pol=None #np.arange(30,35)
    Policy="NoPol"
    filename_Pol = None#lambda folder, seed: filename_noPol(folder, seed)
    folder_Pol=None
    #folder+"Run_N2500_Nc2_T150_policies_trackPath-12,carefulCitizens0.7-12,closeSchools-13,closeLeisure-20,openSchools-27,carefulCitizens0.9-28,closeWork0.7-35,openLeisure-59,openWork0.7-59_seed"+str(seed)+".ncdf"

    plot(folder_NoPol, seeds_noPol, filename_noPol, folder_Pol, seeds_Pol, filename_Pol, Policy, contact_hist_gif=False, school_develop_gif=False)
    

