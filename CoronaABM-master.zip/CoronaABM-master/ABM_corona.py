#!/usr/bin/env python

# Peter, 12.04.2020

import numpy as np
import copy 
import xarray as xr 
import pandas as pd 
from scipy.stats import norm
from scipy.stats import beta as scipybeta
from scipy.optimize import root
from pathlib import Path
from scipy.stats import gamma as scipygamma
import time 
import config
import scipy.spatial.distance

from Plotfunctions import plot




''' 
AGENTS

An agent, i.e. an individual, has specific 
'''

class agent:
    def __init__(self, id, age_group_ind):
        self.id = id  
        # 0,1,2 if 'child', `adult` or `risk` according to probability
        self.age_group_ind =  age_group_ind
        self.pos = np.array([np.nan, np.nan])
       
        # The Nr of random people an agent interacts (i.e. possibly infect) on a day
        self.Nr_random_contacts = max(0,np.round(np.random.normal(config.avg_Nr_randomContacts,config.sig_Nr_randomContacts)))
        # This will be filled by selecting families (or flat-shares, etc.) of size 4.
        self.family=[]
        self.family_onhold=[]
        # This will be filled by groups of agents this agent interacts on a day to day basis, i.e. leisure or colleagues
        self.groups = []
        self.groups_onhold=[]
        self.groups_forbidden=[]
        self.groups_inds=[] 
        
        # Probability of getting infected when in contact with a contagious person.
        #self.infection_rate=config.infection_rates[self.age_group_ind]

        # STATE
        self.state=ind("Healthy")
        self.GotVirusFromExposure=False
        #self.careful = False ## Later: reduce the random group and the friends group
        #self.fraction_of_Contacts_when_careful = config.fraction_of_Contacts_when_careful

        # Times of EVents: Exposure, active Infection, symptom onset, death, recovery.
        self.t_e=np.nan
        self.t_a=np.nan
        self.t_s_potential=np.nan # only helper
        self.t_s=np.nan
        self.severe=np.nan
        self.t_d=np.nan
        self.t_r=np.nan

        self.quarantine = False
        self.quarantine_strict=False
        # For how long have you been in quarantine
        self.quarantine_days = [np.nan,np.nan]
        
        # Counter of contacts
        self.Nr_contacts = 0
        # Nr of people infected by this agent!
        self.r0=np.nan
        self.infector=np.nan

    def start_quarantine(self,t_start):
        if not self.groups==[]:
            self.groups_onhold = copy.deepcopy(self.groups)
            self.groups=[]
        if self.quarantine_strict: #t>self.t_s and self.severe:
            # Note: then quarantine Days are unimportant...
            self.quarantine_Nr_random_contacts = 0
            self.quarantine_strict=True
            self.family_onhold=copy.deepcopy(self.family)
            #for i in self.family:
            # Don't need this: no one in the family will infect the others.
            #    config.all_agents[i].family = config.all_agents[i].family.delete(np.where(config.all_agents[i].family==self.id))
            self.family=[]
        else:
            self.quarantine_Nr_random_contacts = np.round(np.random.normal(loc=config.quarantine_Nr_random_contacts, scale=config.quarantine_Nr_random_contacts_std)).astype(int).clip(min=0)
        self.quarantine=True
        self.quarantine_days[0]=t_start
        return 

    def end_quarantine(self,t):
        self.quarantine=False
        self.quarantine_strict=False
        self.quarantine_days[1]=t
        self.groups=copy.deepcopy(self.groups_onhold)
        self.groups_onhold=[]
        if self.quarantine_strict:
            self.family=copy.deepcopy(self.family_onhold)
            self.family_onhold=[]
        self.quarantine_Nr_random_contacts = np.nan

    def move(self):
        newpos = (self.pos + config.movingRadius * np.array([np.random.random()*2-1, np.random.random()*2-1])) 
        self.pos = np.mod(newpos,1)




def init(N, N_contagious_init):
    ''' Set up healthy population, set up their families and friends. Then make N_contagious_init people sick randomly'''
    # Prepare the storage lists
    config.all_agents = []
    config.policies=[]
    config.store_all_agents= {
        #'state':np.array([]), 
        'time':[], 
        'policies':[], 
        'age_group_ind':[], # immediately
        'Nr_states_agegroup': np.array([[],[],[]]), 
        'Nr_contacts':[], 
        'r0':[[],[]],     
        "group_hist":[],  # immediately
        #"Nr_quarantines":[],
        'WhereInfection':[]
    }

    if not (int(N/4)==N/4):# or not (int(N/10)==N/10):
        print("ERROR! N should be a multiple of 4 (the family size)!")
        quit()

    #########################################
    #####       Setup Agents           ######
    #########################################   

    age_group_inds = np.random.choice([0,1,2], N, p = config.probs_age_group)
    ordered_age_group_inds = np.sort(age_group_inds)
    AgeGroupSizes = [np.sum(ordered_age_group_inds== k ) for k in range(3)]
    for id, age_group_ind in zip(range(N), ordered_age_group_inds):
        ag = agent(id, int(age_group_ind))
        config.all_agents.append(ag)
    
    config.store_all_agents['age_group_ind'] = ordered_age_group_inds

    #########################################
    #####   Setup Friends and Family   ######
    #########################################

    # FIND FAMILY (closed groups of 4 agents)
    print("Set up families")
    indices_arr = np.arange(N)
    for _ in range(int(N/config.N_contacts_family)):
        family_indices = np.random.choice(indices_arr, config.N_contacts_family, replace = False) # These agents are a family
        indices_arr = np.setdiff1d(indices_arr, family_indices) # this removes the current agents from the list of next family members.
        pos = np.array([np.random.random(), np.random.random()])
        for i in family_indices:
            ag = get_agent(i)
            ag.family = np.setdiff1d(family_indices, i)
            ag.pos=pos
            ag.move()



    # WORK, SCHOOL and LEISURE
    print("Set up Work, School and Leisure")
    # config.Dist is the fractions for each age group that goes to Work, School, or has no WorkGroup.
    # I use this to determine the Number of groups needed to get (on average) N_contacts_at_work Agents in one work group for example.
    config.N_workplaces = np.ceil(np.dot(AgeGroupSizes, config.Dist[:,1]) / config.N_contacts_at_work).astype(int) 
    config.N_schools = np.ceil( np.dot(AgeGroupSizes, config.Dist[:,0]) / config.N_contacts_at_school).astype(int) 
    config.N_Leisuregroups_per_age = [np.ceil(AgeGroupSizes[k] / config.N_contacts_in_leisuregroup * config.Nr_leisuregroups_per_person).astype(int) for k in range(3)]
    
    # Store all the groups (with their names) in  group_arr
    group_arr = []
    group_arr.extend(["School["+str(k)+"]" for k in range(config.N_schools)])
    group_arr.extend(["Work["+str(k)+"]" for k in range(config.N_workplaces)])
    for k in range(3):
        group_arr.extend(["Leisure"+config.age_groups[k]+"["+str(j)+"]" for j in range(config.N_Leisuregroups_per_age[k])])

    config.all_groups_sorted=group_arr

    all_groups = [] # I will store all groups and then count how often each occurs

    for ag in config.all_agents:
        # Which group type will this agent belong to?
        work_school_or_nothing = np.random.choice(np.arange(3), 1, p = config.Dist[ag.age_group_ind])            
        if work_school_or_nothing==0:
            ag.groups.append("School"+str(np.random.choice(np.arange(0,config.N_schools), 1)))
            #ag.groups.append(np.random.choice(np.arange(0,N_schools), 1))
        elif (work_school_or_nothing==1):
            ag.groups.append("Work"+str(np.random.choice(np.arange(0,config.N_workplaces), 1)))
            #ag.groups.append(np.random.choice(np.arange(0,N_workplaces), 1))
        else:
            ag.groups_inds.extend([np.nan])
        # Additional assign Leisure groups (e.g. 3)
        leisure_groups = np.random.choice(np.arange(0,config.N_Leisuregroups_per_age[ag.age_group_ind]),config.Nr_leisuregroups_per_person, replace=False)
        for n in range(config.Nr_leisuregroups_per_person):
            #leisure_group_age_ind = ag.age_group_ind
            group  = "Leisure"+config.age_groups[ag.age_group_ind]+"["+str(leisure_groups[n])+"]"
            #group  = np.random.choice(np.arange(0,N_groups_per_age[ag.age_group_ind]),1, replace=False)
            ag.groups.append(group)

        ag.groups_inds.extend([group_arr.index(g) for g in ag.groups])
        
        all_groups.extend(ag.groups)
    

    #group_counts = pd.Series(Counter(group_arr))
    #for ag in config.all_agents:
    #    all_groups.extend(ag.groups)
    group_hist = pd.Series(all_groups).value_counts() #np.histogram(all_groups, bins=np.arange(len(group_id)+1))[0]
    config.store_all_agents["group_hist"] = [group_hist.real, group_hist.index.tolist()]
    

    #####################################################
    ######    Make N_contagious_people contagious    ####
    ##################################################### 

    print("Initialise ",N_contagious_init, "contagious adults(!)")
    first_sick_people = np.random.choice([ag for ag in config.all_agents if ag.age_group_ind==1], size=N_contagious_init, replace=False)
    for ag in first_sick_people:
        ag.state=ind("Latent")
        determine_course_of_infection(ag,0)
        ag.r0=0

    return 



def hugging_round(ag,t, group, random_nr = 1):
    ''' 
    An agent goes round and hugs a group of people (family, groups, ...) exposing them with the virus, 
    Agents become latents with probability = infection rate (global, except for immune people).
    If they do not become latents, they remain healthy
    '''
    if group=="family":
        potential_participants = [config.all_agents[f] for f in ag.family]
    elif "Work" in group or "School" in group or "Leisure" in group:
        potential_participants = [p for p in config.all_agents if (group in p.groups)]
        #if self.careful:
        #    participants = np.random.choice(participants, int(len(participants)* self.fraction_of_Contacts_when_careful))
    elif group=="random":
        #random_nr = random_nr*self.fraction_of_Contacts_when_careful
        #potential_participants = np.random.choice(config.all_agents, size= int(random_nr), replace=False)
        prob = (config.distMatrix[ag.id,:]<config.randomRadius).astype(float)#.clip(min=1e-4)
        prob[ag.id]=0
        availAgents = np.sum(prob).astype(int)
        if availAgents==0:
            return 
        prob = prob/availAgents 
        inds = np.random.choice(np.arange(len(config.all_agents)), replace=False, p=prob, size=min(int(random_nr), availAgents))
        potential_participants = [config.all_agents[i] for i in inds]
    
    # Loop through participants of the hugging_round, with certain probability they get infected.
    for p in potential_participants:
        if (p.quarantine==False or (p.quarantine==True and group=='family')) and (not p.state==ind("Dead")):
            ag.Nr_contacts+=1
            if p.state==ind("Healthy") and not p.GotVirusFromExposure :
                if np.random.random() < ag.p_i(t):
                    p.GotVirusFromExposure=True
                    ag.r0+=1
                    # What kind of infection was it: e.g. Pre-sympt of child to elderly in Random.
                    if ag.state==ind("Active"):
                        if not np.isnan(ag.t_s):
                            InfectionType="Presympt"
                        else:
                            InfectionType="Asympt"
                    elif ag.state==ind("SevereSymptomatic"):
                        InfectionType="Sympt"
                    elif ag.state ==ind("MildSymptomatic"):
                        InfectionType="MildSympt"
                    config.store_all_agents['WhereInfection'].append(group+"_"+InfectionType+"_Infector:"+config.age_groups[ag.age_group_ind]+"_Infectee:"+config.age_groups[p.age_group_ind])
                    p.infector=ag.id
    return 
                        
def ind(state):
    return config.states[state]

def get_agent(id):
    return config.all_agents[[i for i,ag in enumerate(config.all_agents) if ag.id == id][0]]


def update_all_agents(t):
    ''' asynchronosly update each of the agents per time step. Only sick agents perform a hug, then afterwards the state is updated'''
    
    # DIstance Matrix
    positionArr = np.array([ag.pos for ag in config.all_agents])
    config.distMatrix = scipy.spatial.distance.squareform(scipy.spatial.distance.pdist(positionArr))
    
    # order in which agents are updated    
    agent_order = np.random.choice(config.all_agents, len(config.all_agents), replace=False)
    for ag in agent_order: 
        ag.move()
        ag.Nr_contacts=0 
        if not ag.state==ind("Dead"): # only alive agents
            if not ag.state==ind("Healthy") and not ag.state==ind("Immune") and not ag.state==ind("Latent") and not (ag.state==ind("SevereSymptomatic") and ag.quarantine_strict): # only sick agents and latent
                
                # Hug Family
                hugging_round(ag,t, "family")
                if ag.quarantine:
                    # Hug only unavoidable (in best case 0) random people
                    for _ in range(int(ag.quarantine_Nr_random_contacts)):
                        hugging_round(ag,t, "random", random_nr =1)
                    if np.random.random()< (ag.quarantine_Nr_random_contacts-int(ag.quarantine_Nr_random_contacts)):
                        hugging_round(ag,t, "random", random_nr =1)
                else:
                    # Hug Work and School (or nothing)
                    curr_groups = copy.deepcopy(ag.groups)
                    if not len(curr_groups)==0:
                        if "School" in curr_groups[0] or "Work" in curr_groups[0]:
                            hugging_round(ag,t, curr_groups[0])
                            curr_groups.remove(curr_groups[0])
                        # Hug one of the agent's leisure groups.
                        if not len(curr_groups)==0:
                            hugging_round(ag,t, np.random.choice(curr_groups))
                    # Hug a Nr of random People (according to their preference)
                    hugging_round(ag,t, "random", random_nr=ag.Nr_random_contacts)
            # update the state of an agent (healthy, latents, sick)
            update_agent_state(ag, t) 


def determine_course_of_infection(ag,t):
    ag.t_e = t
    ag.GotVirusFromExposure=False
    ag.t_s_potential = ag.t_e + np.exp(np.random.normal(loc=config.mu_Inc, scale=config.sigma_Inc))
    ag.t_a = np.round(ag.t_s_potential - config.He2020_params['shift']).clip(min=ag.t_e).astype(int)

    if np.random.random()<config.ManifestationIndex[ag.age_group_ind]:
        # SYMPTOMATIC 
        ag.t_s = np.round(ag.t_s_potential).clip(min=ag.t_a).astype(int) #t_peakInfect+config.Time_PeakBeforeTs).clip(ag.t_a+1).astype(int)
        if np.random.random()< (config.SevereFraction[ag.age_group_ind]):#/config.ManifestationIndex[ag.age_group_ind]):
            # SEEVERESYMPTOMATIC
            ag.severe=True
            p_i_prefactor = 1
            if np.random.random() < (config.CaseFatalityRate[ag.age_group_ind]/config.SevereFraction[ag.age_group_ind]):
                # GOING TO DIE
                ag.t_d = np.round(ag.t_s + np.random.gamma(config.k_death, scale=config.theta_death)).clip(min=ag.t_s+1).astype(int)
            else:
                # GOING TO SURVIVE
                ag.t_r = np.round(ag.t_s+np.random.gamma(config.k_recov_sympt,scale=config.theta_recov_sympt)).clip(ag.t_s+1).astype(int)
        else:
            # MILDSYMPTOMATIC
            ag.severe = False
            ag.t_r = np.round(ag.t_s+ config.T_truncate_infectiousness).astype(int)
            p_i_prefactor = config.Prefactor_P_i_mildsymptoticTransmission
           
    else:
        # ASYMPTOMATIC
        ag.t_r = np.round(ag.t_s_potential + config.T_truncate_infectiousness).astype(int)#np.random.normal(config.T_avg_recovery_asymptomatic, config.T_sigma_recovery_asymptomatic)).clip(min=ag.t_a+1).astype(int)
        ag.t_s = np.nan
        ag.t_d = np.nan
        p_i_prefactor=config.Prefactor_P_i_asymptoticTransmission
    
    # NEW: USE HE2020 Gamma Distribution
    p_i = lambda t: scipygamma(config.He2020_params['k_i'], scale=1/config.He2020_params['rate_i']).pdf(t-ag.t_a) 
    # For many times:
    # ag.p_i = lambda times: np.array([p_i(t)/np.sum(p_i(np.arange(ag.t_a, ag.t_s_potential+config.T_truncate_infectiousness))) if t<ag.t_s_potential+config.T_truncate_infectiousness else 0 for t in times])
    # For single time t:
    ag.p_i = lambda t: (config.p_i_factor * p_i_prefactor * p_i(t)/np.sum(p_i(np.arange(ag.t_a, ag.t_s_potential+config.T_truncate_infectiousness)))) if t<ag.t_s_potential+config.T_truncate_infectiousness else 0 

    return

def update_agent_state(ag,t):
    ''' update an agents state'''

    ##################
    ## PRE UPDATE ####
    ##################

    if ag.GotVirusFromExposure:
        ag.state=ind("Latent")
        ag.r0=0
        determine_course_of_infection(ag,t)

    if ag.quarantine and not ag.state==ind("SevereSymptomatic") and not ag.state==ind("MildSymptomatic"):
        #ag.quarantine_days
        if (t-ag.quarantine_days[0]) > config.MaxQuarantineDays :
            ag.end_quarantine(t)
    ###########################
    ##    STATE  UPDATE       ##
    ############################
    if ag.state==ind("Healthy") or ag.state==ind("Immune"):
        return # Agent: Healthy --> Healthy
    if t==ag.t_a:
        ag.state = ind("Active")
    if t==ag.t_s:
        if ag.severe:
            ag.state = ind("SevereSymptomatic")
        else: 
            ag.state = ind("MildSymptomatic")
    if ag.state==ind("SevereSymptomatic") or ag.state == ind("MildSymptomatic"):
        if t==ag.t_s + config.quarantine_delay:
            if ag.state==ind("SevereSymptomatic"):
                ag.quarantine_strict=True
            elif ag.state == ind("MildSymptomatic"):
                ag.quarantine_strict=False
            ag.start_quarantine(t)
            if "trackPath" in config.policies: 
                quarantine_all_friendsandfamily(ag,t)
    if t==ag.t_d:
        ag.state = ind("Dead")
    if t==ag.t_r:
        ag.state=ind("Immune")
        if ag.quarantine:
            ag.end_quarantine(t)
        
    return 



###########################
#######   POLICIES   ######
###########################

def quarantine_all_friendsandfamily(ag, ts):
    ''' an agent got sick --> put all his family, work/school, groups into quarantine '''
    for i in ag.family:
        ag_f=get_agent(i)
        ag_f.start_quarantine(ts)
    for g in ag.groups: 
        group = [ag_g for ag_g in config.all_agents if g in ag_g.groups]
        #for ag_g in [get_agent(i) for i in g]:
        for ag_g in group:
            ag_g.start_quarantine(ts)
    return 


def policy_trackPath(t):
    # this enables that as soon as an agent is sick and goes into quarantine, its family, groups, etc. also go into quarantine
    config.policies.append("trackPath")
    for ag in config.all_agents:
        if ag.state==ind("SevereSymptomatic") or ag.state==ind("MildSymptomatic"): 
            if t>=ag.t_s + config.quarantine_delay:    
                quarantine_all_friendsandfamily(ag,ag.t_s)
    return 

def policy_sloppytrackPath(t):
    # this enables that as soon as an agent is sick and goes into quarantine, its family, groups, etc. also go into quarantine
    config.policies.append("sloppytrackPath")
    for ag in config.all_agents:
        if ag.state==ind("SevereSymptomatic"): 
            if t>=ag.t_s + config.quarantine_delay:    
                quarantine_all_friendsandfamily(ag,ag.t_s)
    return 

def policy_closeSchools(t):
    #print("Policy CloseKindergardens is implemented ")
    config.policies.append("closeSchools")
    for ag in config.all_agents:
        if not ag.quarantine:
            for g in ag.groups:
                if "School" in g:
                    ag.groups_forbidden.append(g)
                    ag.groups.remove(g)
        else:
            for g in ag.groups_onhold:
                if "School" in g:
                    ag.groups_forbidden.append(g)
                    ag.groups_onhold.remove(g)
        
def policy_openSchools(t):
    config.policies.append("openSchools")
    for ag in config.all_agents:
        for g in ag.groups_forbidden:
            if "School" in g:
                if not ag.quarantine:
                    ag.groups.insert(0,g)
                else:
                    ag.groups_onhold.insert(0,g)
                ag.groups_forbidden.remove(g)

def policy_closeLeisure(t):
    config.policies.append("closeLeisure")
    for ag in config.all_agents:
        if not ag.quarantine:
            for g in ag.groups:
                if "Leisure" in g:
                    ag.groups_forbidden.append(g)
                    ag.groups.remove(g)
        else:
            for g in ag.groups_onhold:
                if "Leisure" in g:
                    ag.groups_forbidden.append(g)
                    ag.groups_onhold.remove(g)

def policy_openLeisure(t):
    config.policies.append("openLeisure")
    for ag in config.all_agents:
        for g in ag.groups_forbidden:
            if "Leisure" in g:
                if not ag.quarantine:
                    ag.groups.append(g)
                else:
                    ag.groups_onhold.append(g)
                ag.groups_forbidden.remove(g)
            

def policy_closeWork(t, fraction):
    config.policies.append("closeWork"+str(fraction))
    #children = [child for child in config.all_agents if child.age_group_ind==0]
    allWorks = [g for g in config.group_arr_sorted if "Work" in g]
    closeWorks = allWorks[:np.ceil(config.N_workplaces*fraction).astype(int)]
    config.ClosedWorks.extend([w for w in closeWorks if (not w in config.ClosedWorks)])
    for ag in config.all_agents:
        if not ag.quarantine:
            for g in ag.groups:
                if g in closeWorks:
                    ag.groups_forbidden.append(g)
                    ag.groups.remove(g)
        else:
            for g in ag.groups_onhold:
                if g in closeWorks:
                    ag.groups_forbidden.append(g)
                    ag.groups_onhold.remove(g)

def policy_openWork(t, fraction):
    config.policies.append("openWork"+str(fraction))
    # FRACTION OF CLOSED WORKS!!
    #allWorks = [g for g in config.group_arr_sorted if "Work" in g]
    #closeWorks = allWorks[:np.ceil(config.N_workplaces*fraction).astype(int)]
    openWorks = config.ClosedWorks[:np.ceil(len(config.ClosedWorks)*fraction).astype(int)]
    
    for w in openWorks:
        config.ClosedWorks.remove(w)
    for ag in config.all_agents:
        for g in ag.groups_forbidden:
            if g in openWorks:
                if not ag.quarantine:
                    ag.groups.insert(0,g)
                else:
                    ag.groups_onhold.insert(0,g)
                ag.groups_forbidden.remove(g)



def policy_carefulCitizens(fraction, t):
    #print("Policy CarefulCiticens is implemented for Fration ", fraction)
    config.policies.append("carefulCitizens")
    carefulCitizens = np.random.choice(config.all_agents, int(fraction* len(config.all_agents)))
    for ag in carefulCitizens:
        ag.careful = True
        ag.Nr_random_contacts = config.quarantine_Nr_random_contacts
        if not ag.quarantine:
            for g in ag.groups:
                if "Leisure" in g:
                    ag.groups_forbidden.append(g)
                    ag.groups.remove(g)
        else:
            for g in ag.groups_onhold:
                if "Leisure" in g:
                    ag.groups_forbidden.append(g)
                    ag.groups_onhold.remove(g)


def policy_quarantine(fraction, t_start):
    config.policies.append("quarantine"+str(fraction))
    #possible_quarantines = [ag for ag in config.all_agents if ag.quarantine==False]
    possible_quarantines=config.all_agents
    people_willing_to_quarantine = np.random.choice(possible_quarantines, int(fraction* len(possible_quarantines)), replace=False)
    for ag in people_willing_to_quarantine:
        if not ag.quarantine:
            ag.start_quarantine(t_start)
        else:
            ag.quarantine_days[0]=t_start

#def policy_gradualQuarantine(fraction):


####################################################################
#############       OBSERVE AND STORE            ###################
####################################################################
def observe(t):
    config.store_all_agents['time'].append(t)
    config.store_all_agents['policies'].append(config.policies)
    #config.store_all_agents['Nr_quarantines'].append(len([ag for ag in config.all_agents if ag.quarantine]))

    #states = np.array([ag.state for ag in config.all_agents]).reshape((len(config.all_agents), 1))
    
    Nr_states_agegroup=[]
    for k in range(3):
        #agegroup = [ag.id for ag in config.all_agents if ag.age_group_ind==k]
        states_age = np.array([ag.state for ag in config.all_agents if ag.age_group_ind==k])#.reshape((len(config.all_agents), 1))
        Nr_states_agegroup.append(np.histogram(states_age, bins=[0,1,2,3,4,5,6,7])[0])
    Nr_states_agegroup = np.array(Nr_states_agegroup).reshape((3,7,1))

    contacts_hist=np.histogram([ag.Nr_contacts for ag in config.all_agents ], bins=np.arange(41))[0].reshape(40,1)
    #r0_hist = np.histogram([ag.r0 for ag in config.all_agents], bins=np.arange(16))[0].reshape(15,1)
    
    if t == 0:
        #config.store_all_agents['state'] = states
        config.store_all_agents['Nr_states_agegroup'] =  Nr_states_agegroup
        config.store_all_agents['Nr_contacts'] = contacts_hist
    else:
        #config.store_all_agents['state'] = np.append(config.store_all_agents['state'],states,axis=1)
        config.store_all_agents['Nr_states_agegroup'] = np.append(config.store_all_agents['Nr_states_agegroup'], Nr_states_agegroup, axis=2)
        config.store_all_agents['Nr_contacts']= np.append(config.store_all_agents['Nr_contacts'], contacts_hist, axis=1)
        #config.store_all_agents['r0'] =np.append(config.store_all_agents['r0'], r0_hist, axis=1)

    #config.store_all_agents['r0'] = np.array([ag.r0 for ag in config.all_agents])

    #hists = np.histogram(states, bins = [0,1,2,3,4])[0]
    print(str(t)+" (",[np.sum(Nr_states_agegroup[:,k,0]) for k in range(7)], end ="); ")




def save_ncdf(N,N_contagious_init, T, policy_arr, seed, ncdf_name=None):
    ''' This saves the data into a file'''
    
    ds = xr.Dataset(
        {
            #"state":(('id', 'time'),config.store_all_agents['state']),
            "age_group_ind":(('id'),config.store_all_agents['age_group_ind']), 
            "policies":(('time'),[len(p) for p in config.store_all_agents['policies']]),
            "states_detail":(('age_group_ind_coord', 'state_coord', 'time'),config.store_all_agents['Nr_states_agegroup']),
            "Nr_contacts":(('dim_hist_contacts','time'), config.store_all_agents['Nr_contacts']), 
            #"Nr_quarantines":(('time'),config.store_all_agents['Nr_quarantines']),
            "t_e":(('id'),np.array([ag.t_e for ag in config.all_agents])),
            "t_a":(('id'),np.array([ag.t_a for ag in config.all_agents])),
            "t_s":(('id'),np.array([ag.t_s for ag in config.all_agents])),
            "severe":(('id'), np.array([ag.severe for ag in config.all_agents])),
            "t_d":(('id'),np.array([ag.t_d for ag in config.all_agents])),
            "t_r":(('id'),np.array([ag.t_r for ag in config.all_agents])),
            "quarantine_days":(('id','startend'),np.array([ag.quarantine_days for ag in config.all_agents])),
            #"sickdays":(('id','startend'),np.array([ag.sick_days for ag in config.all_agents]),
            "r0":(('id'), np.array([ag.r0 for ag in config.all_agents])),
            "agentgroups":(('id', 'groups'),np.array([ag.groups_inds for ag in config.all_agents])),
            # .insert(0,ag.family) 
            "infector": (('id'),np.array([ag.infector for ag in config.all_agents])),
        }, 
        coords=
            {
                'startend':[0,1],
                'id':np.arange(N), 
                'time': config.store_all_agents['time'],
                'age_group_ind_coord': np.arange(len(config.age_groups)),
                'state_coord': np.arange(len(list(config.states.keys()))),
                'dim_hist_contacts':np.arange(40),
                'groups': ["Work","Leisure1", "Leisure2", "Leisure3" ] #config.store_all_agents["group_hist"][1],
                #'dim_hist_r0':np.arange(15),
            }
        )
    ds.attrs["WhereInfection"]=config.store_all_agents["WhereInfection"]
    ds.attrs["group_hist_hist"]=config.store_all_agents["group_hist"][0]
    ds.attrs["group_hist_index"]=config.store_all_agents["group_hist"][1]
    
    ds.attrs['seed']=seed
    
    ### CORONA PARAMS ###
    ds.attrs['T_inc_avg']=config.T_inc_avg
    ds.attrs['std_inc']=config.std_inc
    ds.attrs['mu_Inc']=config.mu_Inc
    ds.attrs['sigma_Inc']=config.sigma_Inc
    #ds.attrs['PrePeakInfectiousnessPeriod']=config.PrePeakInfectiousnessPeriod
    #ds.attrs['Time_PeakBeforeTs']=config.Time_PeakBeforeTs
    #ds.attrs['Infectivity']=config.Infectivity
    #ds.attrs['p_i_alpha']=config.p_i_alpha    
    #ds.attrs['T_avg_recovery_asymptomatic']=config.T_avg_recovery_asymptomatic
    #ds.attrs['T_sigma_recovery_asymptomatic']=config.T_sigma_recovery_asymptomatic
    ds.attrs['T_avg_recovery_symptomatic']=config.T_avg_recovery_symptomatic
    #ds.attrs['T_sigma_recovery_symptomatic']=config.T_sigma_recovery_symptomatic
    ds.attrs['CoefficientOfVariation_recovery_symptomatic'] = config.CoefficientOfVariation_recovery_symptomatic
    #ds.attrs['characteristicTime_Infectiousness']=config.characteristicTime_Infectiousness
    ds.attrs['ManifestationIndex']=config.ManifestationIndex
    ds.attrs['CaseFatalityRate']=config.CaseFatalityRate
    ds.attrs['T_avg_death']=config.T_avg_death
    ds.attrs['CoefficientOfVariation_death']=config.CoefficientOfVariation_death
    #ds.attrs['sigma_death']=config.sigma_death
    #ds.attrs['symptom_amplification_factor']=config.symptom_amplification_factor

    ds.attrs["T_truncate_infectiousness"] = config.T_truncate_infectiousness
    ds.attrs["He2020_params_k_i"] = config.He2020_params["k_i"]
    ds.attrs["He2020_params_rate_i"] = config.He2020_params["rate_i"]
    ds.attrs["He2020_params_shift"] = config.He2020_params["shift"]
    ds.attrs["R0_noIsolationWithSymptoms"] = config.R0_noIsolationWithSymptoms
    ds.attrs["avg_Nr_randomContacts"]= config.avg_Nr_randomContacts
    ds.attrs["p_i_factor"] = config.p_i_factor
    ds.attrs["Prefactor_P_i_asymptoticTransmission"] = config.Prefactor_P_i_asymptoticTransmission
    ds.attrs["Prefactor_P_i_mildsymptoticTransmission"]= config.Prefactor_P_i_mildsymptoticTransmission

    #ds.attrs['NetworkParams'] = {
    ds.attrs['probs_age_group']=config.probs_age_group
    ds.attrs['N_contacts_at_work']=config.N_contacts_at_work
    ds.attrs['N_contacts_at_school']=config.N_contacts_at_school
    ds.attrs['Dist_Child']=config.Dist[0]
    ds.attrs['Dist_Adult']=config.Dist[1]
    ds.attrs['Dist_Risk']=config.Dist[2]
    ds.attrs['N_contacts_in_leisuregroup']=config.N_contacts_in_leisuregroup
    ds.attrs['Nr_leisuregroups_per_person']=config.Nr_leisuregroups_per_person
    ds.attrs['avg_Nr_randomContacts']=config.avg_Nr_randomContacts
    ds.attrs['sig_Nr_randomContacts']=config.sig_Nr_randomContacts

    ds.attrs['movingRadius']=config.movingRadius
    ds.attrs['randomRadius']=config.randomRadius
    
    ds.attrs['quarantine_delay']=config.quarantine_delay
    ds.attrs['quarantine_Nr_random_contacts']=config.quarantine_Nr_random_contacts
    ds.attrs['MaxQuarantineDays']=config.MaxQuarantineDays

    ds.attrs['N_workplaces']=config.N_workplaces
    ds.attrs['N_schools']=config.N_schools
    ds.attrs['N_Leisuregroups_per_age']=config.N_Leisuregroups_per_age
    ds.attrs['group_arr_sorted'] = config.group_arr_sorted

    params = [N,N_contagious_init, T, ",".join([p[0]+"-"+str(p[1]) for p in policy_arr]),seed]
    name = config.folder+"Run"
    if ncdf_name==None:
        for key,val in zip(["N","Nc", "T", "policies_", "seed"], params):
            ds.attrs[key]=val
            name+="_"+key+str(val)
        ds.attrs["name"]=name
        ds.to_netcdf(name+".ncdf")
    else:
        params = [N,N_contagious_init, T]
        for key,val in zip(["N","Nc", "T"], params):
            ds.attrs[key]=val
            name+="_"+key+str(val)
        name+="_policies_"+ncdf_name
        name+="_seed"+str(seed)
        ds.attrs["name"]=name
        ds.to_netcdf(name+".ncdf")
    return name


import matplotlib.pyplot as plt
def plot_map():
    colors = ["lightgreen", "yellow", "orange", "pink", "r", "k", "darkgreen"]
    positionArr = np.array([ag.pos for ag in config.all_agents])
    colorArr = np.array([colors[ag.state] for ag in config.all_agents])
    plt.scatter(positionArr[:,0], positionArr[:,1], color=colorArr, s=5)
    plt.show()
    return 


def run(N,N_contagious_init, T, policies, seed, save=True, print_anything=True, ncdf_name=None):
    ''' RUN SCRIPT'''

    ############################
    ####  get policies    ######
    ############################
    policy_arr = [['quarantine'+str(f),d, lambda t: policy_quarantine(f,t)] for d,f in policies['quarantine']]
    if policies['closeSchools']:
        policy_arr.extend([['closeSchools', policies['closeSchools'], lambda t: policy_closeSchools(t) ]])
    if policies['openSchools']:
        policy_arr.extend([['openSchools', policies['openSchools'], lambda t: policy_openSchools(t) ]])
    if policies['closeLeisure']:
        policy_arr.extend([['closeLeisure', policies['closeLeisure'], lambda t: policy_closeLeisure(t) ]])
    if policies['openLeisure']:
        policy_arr.extend([['openLeisure', policies['openLeisure'], lambda t: policy_openLeisure(t) ]])
    policy_arr.extend([['closeWork'+str(f),d, lambda t: policy_closeWork(f,t)] for d,f in policies['closeWork']])
    policy_arr.extend([['openWork'+str(f),d, lambda t: policy_openWork(f,t)] for d,f in policies['openWork']])
    if policies['sloppytrackPath']:
        policy_arr.extend([['sloppytrackPath', policies['sloppytrackPath'], lambda t: policy_sloppytrackPath(t)]])
    if policies['trackPath']:
        policy_arr.extend([['trackPath', policies['trackPath'], lambda t: policy_trackPath(t)]])
    if policies['carefulCitizens']:
        policy_arr.extend([['carefulCitizens'+str(f),d, lambda t: policy_carefulCitizens(f,t)] for d,f in policies['carefulCitizens']])
    policy_arr.sort(key=lambda x:x[1])

    np.random.seed(seed)
    init(N, N_contagious_init)
    print("#################### \n ## Run simulation (seed="+str(seed)+") ## \n ####################")
    observe(0)
    time0 = time.time()
    print("")
    for t in range(1,T):
        #plot_map()
        starttime = time.time()
        for p in policy_arr:
            if t==p[1]:
                print("Policy implemented: ",p[0])
                p[2](t)
        update_all_agents(t)
        endtime = time.time()
        observe(t)
        #observetime = time.time()
        print(" Time: ", '%.3f' % (endtime-starttime))#'%.3f' % (observetime-endtime))
        r0s = [ag.r0 for ag in config.all_agents if (not np.isnan(ag.r0) and t>ag.t_r)]
        if len(r0s)>4 and len(r0s)<20:
            print("R0: ",r0s, len(r0s), np.median(r0s), np.mean(r0s))
    if save==True:
        Path(config.folder).mkdir(parents=True, exist_ok=True)
        name = save_ncdf(N,N_contagious_init, T, policy_arr, seed, ncdf_name=ncdf_name)
    else:
        name=False
    print("Total Time:  ", '%.3f' % (time.time()-time0))

    return name
if __name__ == "__main__":
    
    print("Not Doing anything here... Make Runscript")
    # seeds_noPol = np.arange(70,80, step=1)
    # config.folder="/home/peter/Corona/Runs22Apr/NoPol_5000/"
    # folder_NoPol= config.folder #"/home/peter/Corona/RunsFrom12April/NoPolEnsemble2/"
    # filename_noPol = lambda folder, seed: folder + "Run_N5000_Nc4_T150_policies__seed"+str(seed)+".ncdf"

    
    # for seed in seeds_noPol:
    #     #for trackDay in [5,10,15,20,25,30,35,40,45,50]:
    #     print(config.folder)
    #     print(seed)
    #     policies={
    #                 'quarantine':[],  # Note: Now 0.8 fraction means: 0.8 of the total Pop! (perhaps more if of the 20% some are sick and in quarantine)
    #                 'closeSchools':None, 
    #                 'openSchools':None,#13+14,
    #                 'closeLeisure':None, #13+7,
    #                 'openLeisure':None,#,13+31+15,
    #                 'closeWork':[],#[[13+22, fraction]],
    #                 'openWork':[],#,[[13+31+15, fraction]],
    #                 'trackPath':None,#12,
    #                 'carefulCitizens':[],#[[12, 0.7], [13+15,0.9]],
    #                 }
    #     name = run(5000,4, 150, policies, seed)
    #     print(name)
        
    
    # folder_NoPol=  config.folder #"/home/peter/Corona/RunsFrom12April/NoPolEnsemble2/"
    # seeds_Pol=seeds_noPol #np.arange(30,35)
    # Policy="NoPol"
    # filename_Pol = None#lambda folder, seed: filename_noPol(folder, seed)
    # folder_Pol=None
    # #folder+"Run_N2500_Nc2_T150_policies_trackPath-12,carefulCitizens0.7-12,closeSchools-13,closeLeisure-20,openSchools-27,carefulCitizens0.9-28,closeWork0.7-35,openLeisure-59,openWork0.7-59_seed"+str(seed)+".ncdf"

    # plot(folder_NoPol, seeds_noPol, filename_noPol, folder_Pol, seeds_Pol, filename_Pol, Policy, contact_hist_gif=False, school_develop_gif=False)
    


    # #Heinsberg:
    # # 15.2. Start
    # # 27.2. Track Path
    # # 28.2. Close SChools for 14 days (until 13.03.)
    # # 07.03 Close Leisure (???)
    # # Until ttoday 15.4.
    # # 22.03. Close Work  70%
    # # Until today 15.04.

    
    # #config.folder="/home/peter/Corona/RunsFrom12April/TrackPathOnly/"
    # #"Run_N2500_Nc2_T150_policies_trackPath-12,carefulCitizens0.7-12,closeSchools-13,closeLeisure-20,openSchools-27,carefulCitizens0.9-28,closeWork0.7-35,openLeisure-59,openWork0.7-59_seed"+str(seed)+".ncdf"
    
    # seeds_Pol=np.arange(70,80, step=1)
    
    # for t_s in np.arange(20,51,step=10):
    #     config.folder="/home/peter/Corona/Runs22Apr/SchoolCloseOnly_5000_"+str(t_s)+"/"
    #     folder_Pol = config.folder
    #     Policy="Close Schools Day "+str(t_s)

        
    #     for seed in seeds_Pol:
    #         #for trackDay in [5,10,15,20,25,30,35,40,45,50]:
            
    #         print(config.folder)
    #         print(seed)
    #         policies={
    #                     'quarantine':[],  # Note: Now 0.8 fraction means: 0.8 of the total Pop! (perhaps more if of the 20% some are sick and in quarantine)
    #                     'closeSchools':t_s, 
    #                     'openSchools':None,
    #                     'closeLeisure':None,
    #                     'openLeisure':None,
    #                     'closeWork':[],
    #                     'openWork':[],
    #                     'trackPath':None,
    #                     'carefulCitizens':[],
    #                     }
    #         name = run(5000,4, 150, policies, seed)
    #         #print(name)
        
    #     name="Run_N5000_Nc4_T150_policies_closeSchools-"+str(t_s)+"_seedXX"

    #     filename_Pol = lambda folder, seed: folder+name[:-2]+str(seed)+".ncdf"
    #     folder_Pol = "/home/peter/Corona/Runs22Apr/SchoolCloseOnly_5000_"+str(t_s)+"/"
    #     plot(folder_NoPol, seeds_noPol, filename_noPol, folder_Pol, seeds_Pol, filename_Pol, Policy, contact_hist_gif=False, school_develop_gif=False)


    


    #     # HEINSBERG POLICY
    #     #     policies={
    #     #             'quarantine':[],  # Note: Now 0.8 fraction means: 0.8 of the total Pop! (perhaps more if of the 20% some are sick and in quarantine)
    #     #             'closeSchools':13, 
    #     #             'openSchools':13+14,
    #     #             'closeLeisure':13+7,
    #     #             'openLeisure':13+31+15,
    #     #             'closeWork':[[13+22, 0.7]],
    #     #             'openWork':[[13+31+15, 0.7]],
    #     #             'trackPath':12,
    #     #             'carefulCitizens':[[12, 0.7], [13+15,0.9]],
    #     #             }
        